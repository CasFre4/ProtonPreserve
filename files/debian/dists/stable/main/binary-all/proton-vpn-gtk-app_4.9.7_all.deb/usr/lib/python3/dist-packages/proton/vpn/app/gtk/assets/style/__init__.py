"""All the icons the app uses are available in this module."""
from pathlib import Path

STYLE_PATH = Path(__file__).parent
