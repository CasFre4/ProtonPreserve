from abc import abstractmethod, ABCMeta
from protonvpn_nm_lib.enums import ServerStatusEnum, ServerTierEnum
from ..utils import SubclassesMixin


class ServerItemFactory(SubclassesMixin, metaclass=ABCMeta):

    @classmethod
    def factory(cls, type="default"):
        subclasses_dict = cls._get_subclasses_dict("server_item")
        return subclasses_dict[type]

    @property
    @abstractmethod
    def name():
        raise NotImplementedError()

    @property
    @abstractmethod
    def load():
        raise NotImplementedError()

    @property
    @abstractmethod
    def score():
        raise NotImplementedError()

    @property
    @abstractmethod
    def city():
        raise NotImplementedError()

    @property
    @abstractmethod
    def features():
        raise NotImplementedError()

    @property
    @abstractmethod
    def tier():
        raise NotImplementedError()

    @property
    @abstractmethod
    def is_plus():
        raise NotImplementedError()

    @property
    @abstractmethod
    def status():
        raise NotImplementedError()

    @property
    @abstractmethod
    def exit_country_code():
        raise NotImplementedError()

    @property
    @abstractmethod
    def entry_country_code():
        raise NotImplementedError()

    @property
    @abstractmethod
    def has_to_upgrade():
        raise NotImplementedError()

    @property
    @abstractmethod
    def host_country():
        raise NotImplementedError()

    @abstractmethod
    def create():
        raise NotImplementedError()


class ServerItem(ServerItemFactory):
    """ServerItem class.

    Represents a server item in the list of servers. This object stores
    information about a server.

    Properties:
        name : str
            servername
        load: str
            server load
        city: str
            city where the server is located
        features: list
            list of features
        tier: ServerTierEnum
            server tier
        is_plus: bool
            if server is a plus server (shortcut property for tier)
        status: ServerStatusEnum
            server status
        exit_country_code: str
            ISO country code of this servers country
        has_to_upgrade: bool
            if a user has to upgrade to access server
    """
    server_item = "default"

    def __init__(self):
        self.__name: str = None
        self.__load: int = None
        self.__score: int = None
        self.__city: str = None
        self.__features: list = []
        self.__tier: ServerTierEnum = None
        self.__is_plus: bool = None
        self.__status: int = None
        self.__exit_country_code: str = None
        self.__entry_country_code: str = None
        self.__has_to_upgrade: bool = None
        self.__host_country: str = None

    @staticmethod
    def init():
        return ServerItem()

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return "{} || {} ({})".format(
            type(self), self.__name, self.__features
        )

    @property
    def name(self):
        return self.__name

    @property
    def load(self):
        return self.__load

    @property
    def score(self):
        return self.__score

    @property
    def city(self):
        return self.__city

    @property
    def features(self):
        return self.__features

    @property
    def tier(self):
        return self.__tier

    @property
    def is_plus(self):
        return self.__is_plus

    @property
    def status(self):
        return self.__status

    @property
    def exit_country_code(self):
        return self.__exit_country_code

    @property
    def entry_country_code(self):
        return self.__entry_country_code

    @property
    def has_to_upgrade(self):
        return self.__has_to_upgrade

    @property
    def host_country(self):
        return self.__host_country

    def create(self, logical_server, user_tier):
        self.__name = logical_server.name
        self.__load = str(int(logical_server.load))
        self.__score = int(logical_server.score)
        self.__city = logical_server.city
        self.__features = logical_server.features
        self.__tier = ServerTierEnum(logical_server.tier)
        self.__is_plus = self.__check_server_is_plus()
        self.__status = ServerStatusEnum(logical_server.enabled)
        self.__exit_country_code = logical_server.exit_country
        self.__entry_country_code = logical_server.entry_country
        self.__host_country = logical_server.host_country
        self.__has_to_upgrade = (
            True if self.__tier.value > ServerTierEnum(
                user_tier
            ).value else False
        )

    def __check_server_is_plus(self):
        if self.__tier.value < ServerTierEnum.PLUS_VISIONARY.value:
            return False

        return True
