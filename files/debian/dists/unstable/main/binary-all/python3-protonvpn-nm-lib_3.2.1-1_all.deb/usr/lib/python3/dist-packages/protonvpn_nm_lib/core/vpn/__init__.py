from .vpn_configuration import VPNConfiguration

__all__ = ['VPNConfiguration']
