from . import textfile_metadata # noqa

from ._base import MetadataBackend

__all__ = ["MetadataBackend"]
