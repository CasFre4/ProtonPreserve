"""
Copyright (c) 2023 Proton AG

This file is part of Proton VPN.

Proton VPN is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Proton VPN is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ProtonVPN.  If not, see <https://www.gnu.org/licenses/>.
"""
from __future__ import annotations

import itertools
import logging
import random
import time
import weakref
from dataclasses import dataclass
from typing import Sequence, List

from proton.vpn.servers.country_codes import get_country_name_by_code
from proton.vpn.servers.enums import ServerFeatureEnum
from proton.vpn.servers.exceptions import ServerCouldNotBeFound
from proton.vpn.servers.server_types import LogicalServer, PhysicalServer
import copy

logger = logging.getLogger(__name__)


def sort_servers_alphabetically_by_country_and_server_name(server: LogicalServer) -> str:
    """
    Returns the comparison key used to sort servers alphabetically,
    first by exit country name and then by server name.

    If the server name is in the form of COUNTRY-CODE#NUMBER, then NUMBER
    is padded with zeros to be able to sort the server name in natural sort
    order.
    """
    country_name = server.exit_country_name
    server_name = server.name or ""
    server_name = server_name.lower()
    if "#" in server_name:
        # Pad server number with zeros to achieve natural sorting
        server_name = f"{server_name.split('#')[0]}#" \
                      f"{server_name.split('#')[1].zfill(10)}"

    return f"{country_name}__{server_name}"


@dataclass
class Country:
    code: str
    servers: List[LogicalServer]

    @property
    def name(self):
        return get_country_name_by_code(self.code)

    @property
    def is_free(self):
        return any(server.tier == 0 for server in self.servers)


class ServerList:
    """
    This class handles the list of logicals.

    There are two variants:

    - the toplevel list (which contains and owns the data in itself)
    - the sublists, which are in practice views of the toplevel one,with a criteria

    All of these classes refer have an _ids property, which is the list of
    toplevel indices (logicals) this class has access to.

    Example of use :

        .. code-block::

            from proton.vpn.servers import ServerList
            from proton.vpn.servers.enum import ServerFeatureEnum

            s=ServerList()
            s.update_logical_data(...)
            paid_servers = list(filter(lambda server: server.tier > 0, s))
            us_servers = list(filter(lambda server: server.exit_country == 'US', s))
            secure_core_servers = list(
                filter(
                    lambda server: ServerFeatureEnum.SECURE_CORE in server.features,
                    s
                )
            )

    """
    def __init__(
        self, toplevel=None,
        condition=None,
        sort_key=None,
        sort_reverse=False,
        apidata=None
    ):

        if toplevel is not None:
            assert isinstance(toplevel, self.__class__)
            self._toplevel = toplevel
            self._toplevel._views.add(self)
            self._condition = condition
            self._views = set()
        else:
            assert condition is None

            self._toplevel = None
            self._condition = None
            self.__data = apidata or {'LogicalServers': []}
            self._views = weakref.WeakSet()

        self._sort_key = sort_key
        self._sort_reverse = sort_reverse

        self._refresh_indexes()

    def __len__(self):
        return len(self._ids)

    def __getitem__(self, idx):
        if type(idx) == str:
            return self.get_by_id(idx)

        if type(idx) != int:
            raise TypeError(
                f"Invalid index: {idx}. ServerList indices must be integers, "
                f"not {type(idx).__name__}.")

        logical_id = self._ids[idx]
        return self.get_by_id(logical_id)

    def __iter__(self):
        for idx in range(len(self)):
            yield self[idx]

    def __repr__(self):
        if self._is_toplevel:
            return 'ServerList<{} servers>'.format(len(self))
        else:
            return 'ServerList<{}/{} servers>'.format(
                len(self), len(self._toplevel)
            )

    def get_logical_server(self, name: str) -> LogicalServer:
        """
        This method is deprecated, use get_by_name instead.

        Returns a logical server by name.
        :param name: The name of the logical server (e.g. "NL#1").
        :return: The logical server matching the specified name.
        :raises ServerCouldNotBeFound: If there is not a logical server
        with the specified name.
        """
        logger.warning(
            "ServerList.get_logical_server is deprecated."
            "Use ServerList.get_by_name instead."
        )
        return self.get_by_name(name)

    def get_by_name(self, logical_server_name: str) -> LogicalServer:
        """
        Returns a logical server by name.
        :param logical_server_name: The name of the logical server (e.g. "NL#1").
        :return: The logical server matching the specified name.
        :raises ServerCouldNotBeFound: If there is not a logical server
        with the specified name.
        """
        logical = self._logicals_by_name.get(logical_server_name, None)
        if not logical:
            raise ServerCouldNotBeFound(
                f"Server with name \"{logical_server_name}\" could not be found"
            )
        return logical

    def get_by_id(self, logical_server_id: str) -> LogicalServer:
        """
        Returns a logical server by ID.
        :param logical_server_id: The ID of the server.
        :return: The logical server matching the specified ID.
        :raises ServerCouldNotBeFound: If there is not a logical server
        with the specified ID.
        """
        logical = self._logicals_by_id.get(logical_server_id, None)
        if not logical:
            raise ServerCouldNotBeFound(
                f"Server with name \"{logical_server_id}\" could not be found"
            )
        return logical

    def get_fastest_server_in_tier(self, tier: int) -> LogicalServer:
        """ Get a the fastest server according to the load of the Logicals.
        This excludes servers that have Secure-Core and TOR features and which
        are not enabled.
        """
        # Get the fastest enabled server
        servers_ordered = list(
            self.filter(
                lambda server: server.enabled
                and server.tier <= tier
                and ServerFeatureEnum.SECURE_CORE not in server.features
                and ServerFeatureEnum.TOR not in server.features
            ).sort(
                lambda server: server.score
            )
        )
        if len(servers_ordered) == 0:
            raise ServerCouldNotBeFound(
                "No logical server could be found"
            )
        return servers_ordered[0]

    def get_random_server_in_tier(self, tier: int) -> LogicalServer:
        """ Get a random enabled from list of Logicals.
            :returns: LogicalServer
        """
        server_list = list(self.filter(
            lambda server: server.tier <= tier and server.enabled
        ))
        if len(server_list) == 0:
            raise ServerCouldNotBeFound(
                "No logical server could be found"
            )
        return server_list[random.randint(0, len(server_list) - 1)]

    def get_secure_core_servers(self) -> Sequence[LogicalServer]:
        """ Get a list of enabled secure core servers.
        """
        secure_core_servers = list(filter(lambda server: ServerFeatureEnum.SECURE_CORE in server.features, self))
        if len(secure_core_servers) == 0:
            secure_core_servers = []

        return secure_core_servers

    def filter_servers_by_tier(self, tier: int) -> Sequence[LogicalServer]:
        """ Return a list of server list below or equal to a given tier, regardless if servers
        are enabled or not.
        """
        # Filter servers by tier
        server_list = list(self.filter(
            lambda server: server.tier <= tier # noqa
        ))
        if len(server_list) == 0:
            server_list = []

        return server_list

    @property
    def data(self):
        if self._is_toplevel:
            return self.__data
        else:
            return self._toplevel.__data

    def match_server_domain(self, physical_server) -> PhysicalServer:
        """
        There are multiple physical servers that have the same exit IP but have different domains.
        Thus (and specifically for OpenVPN), doing TLS authentication with the existing domains in each
        physical server might fail, thus, in logicals list we need to find another physical server
        which shares the same exit, and fetch it's domain.
        Otherwise if there is none then we just assume that the one we have withing the `physical_server` is
        the correct one.
        """
        shallow_copy_server = copy.deepcopy(physical_server)
        domain = shallow_copy_server.domain

        for logical_server in self:
            if ServerFeatureEnum.SECURE_CORE in logical_server.features:
                continue

            servers = logical_server.physical_servers
            servers = [
                _physical_server
                for _physical_server
                in servers
                if _physical_server.exit_ip == shallow_copy_server.exit_ip
                and _physical_server.id != shallow_copy_server.id
            ]

            if len(servers) > 0:
                domain = servers[0].domain
                break

        shallow_copy_server.domain = domain
        return shallow_copy_server

    def update_logical_data(self, data) -> None:
        """Fill the server list with logicals data coming from the API
        """
        self._ensure_toplevel()
        self.__data = data
        # We update both LastLogicalUpdate and LastLoadUpdate
        self.__data["LogicalsUpdateTimestamp"] = time.time()
        self.__data["LoadsUpdateTimestamp"] = time.time()

        self._refresh_indexes()

    def update_load_data(self, data: dict) -> None:
        """ Fill the server list with load data coming from the API
        """
        self._ensure_toplevel()

        for s in data.get("LogicalServers", []):
            logical_id = s.get("ID")
            if logical_id not in self._logicals_by_id:
                # This server doesn't exist in the cached list
                continue

            server = self.get_by_id(logical_id)

            server.load = s.get("Load", server.load)
            server.score = s.get("Score", server.score)
            server.enabled = s.get("Status", server.enabled)

        # Update LoadsUpdateTimestamp with current time
        self.__data["LoadsUpdateTimestamp"] = time.time()

        # Required to sort lists again if needed
        self._refresh_indexes()

    def sort(
            self,
            key: callable = sort_servers_alphabetically_by_country_and_server_name,
            reverse=False
    ) -> ServerList:
        """
        Sorts the current ServerList in place and returns it.

        If a key is not specified, then the servers will be sorted alphabetically
        by country name and then server name.

        Example: sort the servers by name:
        sl.sort(lambda x: x.name)

        :param key: Callable returning the comparison key to sort the list.
        :param reverse: True if the list should be reversed, False otherwise.
        :returns: Itself.
        """
        self._sort_key = key
        self._sort_reverse = reverse
        return self._sort()

    def filter(self, condition):
        if self._is_toplevel:
            return ServerList(self, condition)
        else:
            return ServerList(
                self._toplevel,
                lambda x: self._condition(x) and condition(x)
            )

    def group_by_country(self) -> List[Country]:
        """
        Returns the servers grouped by country.

        Before grouping the servers, they are sorted alphabetically by
        country name and server name.

        :return: The list of countries, each of them containing the servers
        in that country.
        """
        self.sort()
        return [
            Country(country_code, list(country_servers))
            for country_code, country_servers in itertools.groupby(
                self, lambda server: server.exit_country.lower()
            )
        ]

    @property
    def logicals_update_timestamp(self):
        return self.data.get('LogicalsUpdateTimestamp', 0.)

    @property
    def loads_update_timestamp(self):
        return self.data.get('LoadsUpdateTimestamp', 0.)

    @property
    def _is_toplevel(self):
        return self._toplevel is None

    def _ensure_toplevel(self):
        if not self._is_toplevel:
            raise ValueError(
                "This function has to be called in "
                "a toplevel ServerList"
            )

    def _refresh_indexes(self):
        # Create indexes
        self._ids = []
        self._logicals_by_id = {}
        self._logicals_by_name = {}

        # Re-apply filter condition (if any)
        for logical_dict in self.data.get("LogicalServers", {}):
            logical_server = LogicalServer(logical_dict)
            if self._condition is None or self._condition(logical_server):
                self._logicals_by_id[logical_dict["ID"]] = logical_server
                self._logicals_by_name[logical_dict["Name"]] = logical_server
                self._ids.append(logical_dict["ID"])

        # Re-apply filter condition on children (if any)
        for v in self._views:
            v._refresh_indexes()

        # Sort (if needed)
        self._sort()

    def _sort(self):
        """Sort (or re-sort) the list"""
        if self._sort_key:
            self._ids.sort(
                key=lambda logical_id: self._sort_key(
                    self._logicals_by_id[logical_id]
                ),
                reverse=self._sort_reverse
            )

        # This is practical as we can chain these calls
        return self
