## 4.0.0-a13
- We added a new settings window to the app. You can now enable port forwarding, auto-connect, and other VPN features in just a few clicks.
