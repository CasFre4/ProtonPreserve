## 4.0.0-a16
- Kill Switch: you can now prevent unprotected access to the internet if you lose your VPN connection.

## 4.0.0-a15
- Pinned Tray Connections: with this new setting you can now pin you frequently used connections and access them from system tray for quick connectivity.
- Moderate NAT: with this setting you can disable randomization of the local addresses mapping for greater gaming performances.

## 4.0.0-a13
- We added a new settings window to the app. You can now enable port forwarding, auto-connect, and other VPN features in just a few clicks.
